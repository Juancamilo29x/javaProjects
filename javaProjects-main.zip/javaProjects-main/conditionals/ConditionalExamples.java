package conditionalexamples;

public class ConditionalExamples {

    public static void main(String[] args) {
        // TODO code application logic here
        int x = 10;    
        int y = 12;    
        if(x+y > 20) {    
            System.out.println("x + y is greater than 20");    
        }    
    }      
}