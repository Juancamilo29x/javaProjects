//Compound operators:
/*
Addition (+=)
Subtraction (-=)
Multiplication (*=)
Division (/=)
Modulo (%=)
*/ 

public class BakeSale {
	public static void main(String[] args) {   
		int numCookies = 17;
    numCookies -= 3;
    System.out.println(numCookies);
    numCookies /= 2;
    // Add your code above
    System.out.println(numCookies);
	}
}
