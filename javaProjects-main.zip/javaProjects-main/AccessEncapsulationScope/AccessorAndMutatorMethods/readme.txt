Introducción a métodos de acceso hacia atributos privados. 
