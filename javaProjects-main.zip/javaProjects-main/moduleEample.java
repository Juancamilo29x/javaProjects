public class Modulo {
	public static void 

		int students = 26;
    int leftOut = students%3; 

    System.out.println(leftOut);
	}
}
