public class Final {
	public static void main(String[] args) { 
    final double pi = 3.14;
    System.out.println(pi);  
    pi = 2*pi;  //Note that pi is unchangable
		
	}
}
