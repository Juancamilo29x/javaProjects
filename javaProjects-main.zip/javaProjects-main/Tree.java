class Tree  
{    
    public static void main(String args[]) {  
       System.out.println("Hey there, I’m Henry and I’m learning to code in Java!");
       System.out.println("I’m going to plant a tree today!” or “Ready to get my hands dirty!");
       System.out.println("   *   ");
       System.out.println("  ***  ");
       System.out.println("*******");
       System.out.println(" *****  ");
       System.out.println("  ***  ");
       System.out.println("   *  ");
       System.out.println("   *  ");
       System.out.println("   *  ");
       System.out.println("   *  ");
   }  
}  
