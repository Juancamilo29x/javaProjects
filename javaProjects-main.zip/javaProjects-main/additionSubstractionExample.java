public class PlusAndMinus {
	public static void main(String[] args) {   
		int zebrasInZoo = 8;
    int giraffesInZoo = 4;
    int animalsInZoo = zebrasInZoo + giraffesInZoo;
    
    System.out.println(animalsInZoo); 

    int numZebrasAfterTrade = zebrasInZoo - 2;

    System.out.println(numZebrasAfterTrade);


	}
}
