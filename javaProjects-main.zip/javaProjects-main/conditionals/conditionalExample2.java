package conditionalexamples;

public class conditionalExample2 {
    
    public static void main(String[] args) {
    
        int x = 10;  
        int y = 12;  
    
        if(x+y < 10) {  
            System.out.println("x + y is less than      10");  
        }   
    else {  
        System.out.println("x + y is greater than 20");  
        }  
    }
}    