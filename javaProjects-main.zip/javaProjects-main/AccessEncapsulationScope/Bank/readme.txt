Este proyecto introduce al concepto de acceso público y privado entre clases.
