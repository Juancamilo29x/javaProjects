public class Creator {
	public static void main(String[] args) {
    String name = "James Gosling";
    int yearCreated = 1995;      //The int data type allows values between -2,147,483,648 and 2,147,483,647, inclusive.
    System.out.println(name);
    System.out.println(yearCreated);
	}
}
